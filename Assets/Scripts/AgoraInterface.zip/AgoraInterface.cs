using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using agora_gaming_rtc;

public class AgoraInterface : MonoBehaviour
{
    private static string appId= "b8ffb2e93e004dae9734e44b80c5489f";
    public IRtcEngine mRTcEngine;
    public uint mRemotePeer;

    public void loadEngine(){
        // start SDK
        Debug.Log("Initialize engine");
        if(mRTcEngine != null){
            Debug.Log("IRtcEngine already exist. PLease unload it first");
            return;
        }

        //init Engine
        mRTcEngine = IRtcEngine.getEngine(appId);

        // set log level
        mRTcEngine.SetLogFilter(LOG_FILTER.DEBUG);
    }

    public void JoinChannel(string channelName){
        Debug.Log("Joining Channel:"+ channelName);
    
        if(mRTcEngine == null){
            Debug.Log("mRTcEngine needs to be initializes before joining the channel");
            return;
        }
        
        // callbacks
        mRTcEngine.OnJoinChannelSuccess = OnJoinChannelSuccess;
        mRTcEngine.OnUserJoined = OnUserJoined;
        mRTcEngine.OnUserOffline = OnUserOffline;

        // join Video
        mRTcEngine.EnableVideo();

        // allow camera output callback
        mRTcEngine.EnableVideoObserver();

        // join channel
        mRTcEngine.JoinChannel(channelName,null,0);

    }

     public void LeaveChannel(){
        Debug.Log("Leaving Channel:");
    
        if(mRTcEngine == null){
            Debug.Log("mRTcEngine needs to be initializes before leaving the channel");
            return;
        }

        // join Video
        mRTcEngine.LeaveChannel();

        // allow camera output callback
        mRTcEngine.DisableVideoObserver();
    }

    public void unloadEngine(){
        Debug.Log("unloading engine");

         if(mRTcEngine != null){
            IRtcEngine.Destroy();
            mRTcEngine= null;

            return;
        }
    }

    // implement callbacks

    void OnJoinChannelSuccess(string channelName, uint uid, int elapsed){
        Debug.Log("Successfully joined channel:"+ channelName +" with Uid:"+ uid);
    }

     void OnUserJoined(uint uid, int elapsed){
        Debug.Log("Used has joined channel with Uid:"+ uid);
        // add remote stream to scene

        // create a gameObject
        GameObject go;
        go = GameObject.CreatePrimitive(PrimitiveType.Plane);
        go.name = uid.ToString();

        // Configure video surface
        VideoSurface o = go.AddComponent<VideoSurface>();
        o.SetForUser(uid);
        // o.mAdjustTransform += OntransformDelegate;
        o.SetEnable(true);
        o.transform.Rotate(-900f,0.0f,0.0f);
        float r= Random.Range(-5.0f,5.0f);
        o.transform.position = new Vector3(0f,r,0f);
        o.transform.localScale = new Vector3(0.5f,0.5f,1.0f);

        mRemotePeer = uid;


    }

    void OntransformDelegate(uint uid, string objName, ref Transform transform){
        if(uid==0){
            transform.position =new Vector3(0f,2f,0f);
            transform.localScale = new Vector4(2.0f,2.0f,2.0f);
        }
        else{
            transform.Rotate(0.0f,1.0f, 0.0f);
        }
    }
      void OnUserOffline(uint uid, USER_OFFLINE_REASON reason){
        Debug.Log("Used with Uid:"+ reason + " ahs left the channel");

        // remove the game object from the scene
        GameObject go = GameObject.Find(uid.ToString());
        if(!ReferenceEquals(go,null)){
            Destroy(go);
        }
    }

    void OnChatSceneLoaded(){
        // 
        GameObject go  = GameObject.Find("Cylinder");
         if(!ReferenceEquals(go,null)){
            Debug.Log("Unable to find cylinder");
        }

        // add delegate
        VideoSurface o = go.GetComponent<VideoSurface>();
        // o.mAd

    }

}
