using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManageItems : MonoBehaviour
{
    public GameObject Pencil;

    public bool objectState = true;
    public bool activeSelf;

    void Start()
    {
        objectState  = activeSelf;

    }

    void Update()
    {
        if(Input.GetKeyDown(KeyCode.P)){
            TogglePencil();
            Debug.Log("P pressed");
            Debug.Log(objectState);
        }
    }

     void TogglePencil(){
        Pencil.SetActive(!objectState);
        objectState = ! objectState;
    }
}
