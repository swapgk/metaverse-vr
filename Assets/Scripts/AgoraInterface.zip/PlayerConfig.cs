using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

 using UnityStandardAssets.Characters.FirstPerson;




public class PlayerConfig : MonoBehaviourPunCallbacks
{
    public GameObject playerCamera;
    private PhotonView PV;
    
    private void Start()
    {   
        PV = GetComponent<PhotonView>();
        RigidbodyFirstPersonController controller = 
            this.GetComponent<RigidbodyFirstPersonController>();

        Camera myCamera = playerCamera.GetComponent<Camera>();

        AudioListener audioListener = playerCamera.GetComponent<AudioListener>();

        if (PV.IsMine)
        {
            controller.enabled = true;
            myCamera.enabled = true;
            audioListener.enabled = true;

        }
        else
        {
            controller.enabled = false;
            myCamera.enabled = false;
            audioListener.enabled = false;

            print("Incorrect PhotonView");        
        }
    }
}
