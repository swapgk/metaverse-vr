using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;

public class LaunchManager : MonoBehaviourPunCallbacks
{
    public GameObject JoinMeetingPanel;
    public GameObject ConnectionStatusPanel;
    public GameObject LobbyPanel;
    
    public string roomName;

    void Awake() {
        PhotonNetwork.AutomaticallySyncScene = true;
    }

    void Start()
    {
        JoinMeetingPanel.SetActive(true);
        ConnectionStatusPanel.SetActive(false);
        LobbyPanel.SetActive(false);

    }

    void Update()
    {
        // Debug.Log("PlayerNames: ");
        // foreach (Player player in PhotonNetwork.PlayerList) 
        // {
        //     Debug.Log(player.NickName);
        // }
    }

    public override void OnConnectedToMaster()
    {
        Debug.Log(PhotonNetwork.NickName+ ": Connect to Photon Master!");
        LobbyPanel.SetActive(true);

    }

    public override void OnConnected()
    {
        Debug.Log("Connected to Internet!");
    }

    public void ConnectToPhotonServer(){
        if(!PhotonNetwork.IsConnected){
            PhotonNetwork.ConnectUsingSettings();
            JoinMeetingPanel.SetActive(false);
            ConnectionStatusPanel.SetActive(true);
        }
    }


    public void JoinOrCreateRoom()
    {
        Debug.Log("Creating room...");
        roomName = RoomNameInputManager.roomName;

        RoomOptions roomOptions = new RoomOptions();
        roomOptions.IsOpen = true;
        roomOptions.IsVisible  = true;
        roomOptions.MaxPlayers = 20;

        PhotonNetwork.JoinOrCreateRoom(roomName,roomOptions,null);
    }

    public override void OnJoinRoomFailed(short returnCode, string message)
    {
        base.OnJoinRoomFailed(returnCode, message);
        Debug.Log(message);
    }

    public override void OnJoinedRoom()
    {
        Debug.Log(PhotonNetwork.NickName + ",Joined Room:"+ PhotonNetwork.CurrentRoom.Name);
        // 
        PhotonNetwork.LoadLevel("MeetingScene");
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        Debug.Log("OnPlayerEnteredRoom");
        Debug.Log(newPlayer.NickName + " joined to"
            + PhotonNetwork.CurrentRoom.Name + " "
            + PhotonNetwork.CurrentRoom.PlayerCount);
    }


}
