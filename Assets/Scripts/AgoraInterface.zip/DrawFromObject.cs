using UnityEngine;
using UnityEngine.Rendering;

/* 
The object to which this file is attached will act as a drawing tool
 */
public class DrawFromObject : MonoBehaviour
{
    private LineRenderer Line;
    private Vector3 pointerPos;
    public Material material;

    private int currLines = 0;
    public float minimumVertexDistance = 0.1f;
    private bool isLineStarted;
    
    public bool activeSelf;
 
    void Start()
    {
    }
 
    void Update()
    {   
        pointerPos = (transform.position);

        if (Input.GetMouseButtonDown(0))
        {
            PrecessLeftMouseClick();
        }
        else if (Input.GetMouseButtonUp(0) && Line)   // stop drawing line
        {
            Line = null;
            currLines++;
            isLineStarted = false;
        }
        else if (Input.GetMouseButton(0) && Line)
        {
            WhileLeftMousePressing();
        }
    }

   


    private void PrecessLeftMouseClick()
    {
        if (Line == null)
        {
            createLine();
        }
        pointerPos = (transform.position);
        // Debug.Log("pointerPos after" + pointerPos);
        Line.positionCount = 2;
        Line.SetPosition(0, pointerPos);
        Line.SetPosition(1, pointerPos);
        isLineStarted = true;
    }

    void createLine()
    {
        Line = new GameObject("Line" + currLines).AddComponent<LineRenderer>();
        Line.material = material;
        Line.positionCount = 2;
        Line.startWidth = 0.15f;
        Line.endWidth = 0.15f;
        Line.useWorldSpace = false;
        Line.numCapVertices = 50;

        isLineStarted = false;

    }

    private void WhileLeftMousePressing()
    {
        Vector3 currentPos = (transform.position);
        float distance = Vector3.Distance(currentPos, Line.GetPosition(Line.positionCount - 1));
        if (distance > minimumVertexDistance)
        {
            UpdateLine();
        }
    }
    private void UpdateLine()
    {
        Line.positionCount++;
        pointerPos =  (transform.position);

        Line.SetPosition(Line.positionCount - 1, pointerPos);
        Debug.Log("pointerPos before" + pointerPos);

    }

    private Vector3 GetWorldCoordinate(Vector3 mousePositionV)
    {
        Vector3 pointerPos = new Vector3(mousePositionV.x, mousePositionV.y, mousePositionV.z);
        return Camera.main.ScreenToWorldPoint(pointerPos);
    }
    
}